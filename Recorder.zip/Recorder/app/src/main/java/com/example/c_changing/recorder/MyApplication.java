package com.example.c_changing.recorder;

import android.app.Application;
import android.content.Context;
import android.os.Handler;

public class MyApplication extends Application {
    //在整个应用执行的过程中，需要提供的变量
    public static Context context;//需要使用的上下文对象
    public static Handler handler;//需要使用的Handler
    public static Thread mainThread;//提供主线程对象
    public static int mainThreadId;//提供主线程对象的Id
    private static MyApplication instance;

    @Override
    public void  onCreate() {
        super.onCreate();
        context=this.getApplicationContext();
        handler=new Handler();
        mainThread= Thread.currentThread();//实例化Application当前的线程为主线程
        mainThreadId= android.os.Process.myTid();//获取当前线程的Id
        instance = this;
    }
    public static Context getApplication() {
        return instance;
    }
}

