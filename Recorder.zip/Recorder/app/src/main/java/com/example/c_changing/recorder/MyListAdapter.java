package com.example.c_changing.recorder;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class MyListAdapter extends BaseAdapter {
    private List<ItemBean> mList;//数据源
    private LayoutInflater mInflater;//布局装载器对象
    private ButtonCircleProgressBar processBar;
    private  ItemBean bean;
    // 通过构造方法将数据源与数据适配器关联起来
    // context:要使用当前的Adapter的界面对象
    public MyListAdapter(Context context, List<ItemBean> list) {
        mList = list;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    //ListView需要显示的数据数量
    public int getCount() {
        return mList.size();
    }

    @Override
    //指定的索引对应的数据项
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    //指定的索引对应的数据项ID
    public long getItemId(int position) {
        return position;
    }

    @Override
    //返回每一项的显示内容
    public View getView(final int position, View convertView, ViewGroup parent) {
        //将布局文件转化为View对象
        View view = mInflater.inflate(R.layout.item,null);

        /**
         * 找到item布局文件中对应的控件
         */
        //ImageView imageView = (ImageView) view.findViewById(R.id.iv_image);
        bean = mList.get(position);
        final String contex = bean.itemContent;
        TextView contentTextView = (TextView) view.findViewById(R.id.tv_content);
        processBar = (ButtonCircleProgressBar)view.findViewById(R.id.progressBar);
        bean.mProgressBar = (ButtonCircleProgressBar) processBar;
        processBar.setProgress(0);
        processBar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                bean = mList.get(position);
                ButtonCircleProgressBar progressBar = v.findViewById(R.id.progressBar);
                if(bean.mediaPlayer != null){
                    if(bean.mediaPlayer.isPlaying()){
                        bean.mHandler.removeMessages(0x110);
                        progressBar.setStatus(ButtonCircleProgressBar.Status.End);
                        progressBar.setProgress(0);
                    }
                    bean.mediaPlayer.stop();
                    try {
                        bean.mediaPlayer.prepare();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });
        processBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ButtonCircleProgressBar progressBar = view.findViewById(R.id.progressBar);
                bean = mList.get(position);
                //processBar.setProgress(0);
                bean.runmusic(progressBar);
                /*if (processBar.getStatus()== ButtonCircleProgressBar.Status.Starting){
                    processBar.setStatus(ButtonCircleProgressBar.Status.End);
                    bean.mHandler.removeMessages(bean.MSG_PROGRESS_UPDATE);
                }else{
                    bean.mHandler.sendEmptyMessage(bean.MSG_PROGRESS_UPDATE);
                    processBar.setStatus(ButtonCircleProgressBar.Status.Starting);
                }*/
            }
        });
        Button delete = (Button)view.findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File f = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/SavAudio/"+contex);
                f.delete();
                mList.remove(position);
                MyListAdapter.this.notifyDataSetChanged();
            }
        });
        //获取相应索引的ItemBean对象

        /**
         * 设置控件的对应属性值
         */
        //imageView.setImageResource(bean.itemImageResId);
        //processBar.setProgress(0);
        contentTextView.setText(contex);

        return view;
    }

}
